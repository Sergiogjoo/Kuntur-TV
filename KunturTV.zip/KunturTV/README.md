# Kuntur TV (Android nativo)

App nativa en Kotlin + Jetpack Compose + Media3 (ExoPlayer).

## Abrir y compilar
1. Abre la carpeta en Android Studio (Koala o superior). Sincroniza Gradle.
2. Run ▶ en un dispositivo/emulador, o Build > Generate Signed Bundle / APK para publicar.

## Canales
Edita `app/src/main/assets/channels.json`:
- `streamUrl`: URL directa HLS (.m3u8) AUTORIZADA por el canal. Si la llenas, se reproduce dentro de la app.
- `officialUrl`: página oficial del canal. Si `streamUrl` está vacío, el botón "Ver en vivo" la abre.

Usa solo señales que el canal publique oficialmente o para las que tengas permiso.
Verifica que cada `officialUrl` sea correcta antes de publicar.

## Logo
`app/src/main/res/drawable/ic_logo.xml` (vector). Se usa en el splash, el ícono y la pantalla de inicio.
