package pe.kuntur.tv

import android.content.Context
import org.json.JSONObject

data class Channel(
    val id: String,
    val name: String,
    val category: String,
    /** URL directa de la señal (HLS .m3u8 u otra compatible con Media3). Vacía si no hay. */
    val streamUrl: String,
    /** Página oficial del canal; se abre como alternativa si no hay streamUrl. */
    val officialUrl: String
)

object ChannelRepository {
    fun load(context: Context): List<Channel> {
        val json = context.assets.open("channels.json").bufferedReader().use { it.readText() }
        val arr = JSONObject(json).getJSONArray("channels")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Channel(
                id = o.getString("id"),
                name = o.getString("name"),
                category = o.optString("category", "Nacional"),
                streamUrl = o.optString("streamUrl", ""),
                officialUrl = o.optString("officialUrl", "")
            )
        }
    }
}
