package pe.kuntur.tv.ui

import android.content.Intent
import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import pe.kuntur.tv.Channel

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(channel: Channel, onBack: () -> Unit) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
    ) {
        Box(Modifier.fillMaxWidth().padding(4.dp), contentAlignment = Alignment.CenterStart) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
            }
            Text(
                channel.name,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                modifier = Modifier.padding(start = 52.dp)
            )
        }

        if (channel.streamUrl.isNotBlank()) {
            var loading by remember { mutableStateOf(true) }
            var error by remember { mutableStateOf<String?>(null) }

            val player = remember(channel.id) {
                ExoPlayer.Builder(context).build().apply {
                    setMediaItem(MediaItem.fromUri(channel.streamUrl))
                    playWhenReady = true
                    prepare()
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            loading = state == Player.STATE_BUFFERING || state == Player.STATE_IDLE
                        }

                        override fun onPlayerError(e: PlaybackException) {
                            error = "No se pudo reproducir la señal. Verifica tu conexión."
                        }
                    })
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }

            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }
                )
                if (loading && error == null) {
                    CircularProgressIndicator(color = PeruRed, modifier = Modifier.align(Alignment.Center))
                }
            }
            error?.let {
                Text(it, color = Color(0xFFFF8A8A), modifier = Modifier.padding(16.dp))
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                Text(
                    "Señal oficial de ${channel.name}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    "Este canal se reproduce desde su transmisión oficial.",
                    color = Color(0xFF9AA3B2),
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.size(20.dp))
                Button(
                    onClick = {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse(channel.officialUrl))
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PeruRed)
                ) { Text("Ver en vivo") }
            }
        }
    }
}
